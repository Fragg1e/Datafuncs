# Data Funcs

Functions for Data Processing