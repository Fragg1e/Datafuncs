# Data Funcs

Functions for Data Processing

## Functions

.mean - Returns the mean of a list

.grt - Returns the mean of a list for values greater than specified

.grtEqual - Returns the mean of a list for values greater than or equal to specified

.less - Returns the mean of a list for values less than specified

.lessEqual - Returns the mean of a list for values less than or equal to specified

.notEqual - Returns the mean of a list for values not equal to specified

.outlier - Removes the outliers from a list

.imputate - Replaces outliers in a list with the mean of the filtered list.

.median - Returns the median of a list

.mode - Returns the mode of a list

.Help - Prints a list of the above functions and their explanations

### Created by Liam Leonard & Fraser Woodward